# @smbc/ui

Reusable SMBC React components, version **0.1.0**. The `smbc-style` project is
the integration reference. Reflect public behaviour and visual changes there
in the same change/release cycle.

## Installation

Use your approved internal registry (for example Nexus):

```sh
npm install @smbc/ui@0.1.0 @smbc/devextreme-theme@0.1.0 devextreme@26.1.4 devextreme-react@26.1.4 react@19.2.8 react-dom@19.2.8
```

Peer contracts: React/React DOM `^19.2.8`, DevExtreme/DevExtreme React `~26.1.4`,
SMBC theme `^0.1.0`. None of these runtimes is bundled. This is a browser React
library intended for an ESM bundler such as Vite; Node SSR is not a supported
v0.1 target. Use Vite's `vite/client` types for CSS imports in TypeScript.

Configure the approved `@smbc:registry` before publishing. `prepublishOnly`
rejects the public npm registry. Metadata uses `UNLICENSED`, `private: false`,
and restricted access; no public registry URL is configured. Publishing is an
explicit release operation, separate from building and packing.

## Styles and ownership

```ts
import '@smbc/devextreme-theme/styles.css';
import '@smbc/ui/styles.css';
```

Both CSS imports are required. Do not also load a stock DevExtreme theme.
Tailwind **4.3.3** is a build-time implementation detail: `scripts/build.mjs`
compiles component utilities with the official `@tailwindcss/cli` into the
published `styles.css`. Consumers need no Tailwind installation, plugin,
configuration, or scan of `node_modules/@smbc/ui`. The installed-tarball test
uses a consumer with no Tailwind and verifies both appearance and behaviour.
No Tailwind Preflight or document typography/reset is included.

Component layout, spacing, typography and semantic decoration live next to JSX
as `ui:` prefixed utilities. They reference the theme's CSS-first bridge and
canonical variables, never a library-owned palette. The prefix prevents
collisions with an application's unprefixed Tailwind utilities. Generated
`--tw-*` properties are compiler bookkeeping, not SMBC design tokens.

`src/styles/devextreme-overrides.css` centralizes the remaining private vendor
integration hooks (`Field` radio spacing, Card toolbar background, TableShell
grid borders/freespace, EmptyState icon sizing). Global corporate DevExtreme corrections remain in the
theme package. Do not scatter `.dx-*` selectors across React components.

### Composition and className

For HTML-based components, `className` adds layout/presentation to the root.
It is additive, not a guarantee that conflicting utilities override internal
styles by their order in the HTML. Use semantic props for supported variants;
wrap components for layout when necessary. No `tailwind-merge` dependency is
needed. A Tailwind application can deliberately place its utilities in a layer
after shared components, as the reference does. Private `smbc-ui-*` hooks and
`ui:` implementation classes are not public styling APIs.

Use ordinary `div` elements with application utilities for generic flex/grid
composition. Do not introduce Stack/Row/Grid abstractions merely to hide CSS.
StatusBadge and Callout use explicit tone maps so all variants are compiled.

`FilterPanel` owns its surface and padding; applications own the field layout.
For example, use `className="grid grid-cols-1 gap-x-4 gap-y-3 md:grid-cols-2 xl:grid-cols-4"`
on the panel and `className="md:col-span-2"` on a Field that spans two columns.
Consumers without Tailwind can supply ordinary application CSS through className;
the panel's own appearance is still included in `styles.css`.

### Layout API migration

`Field wide` and `Toolbar.Group` have been removed during local 0.1.0 development.
Replace `wide` with application layout classes. Replace Group with an ordinary
`div` inside `Toolbar.Item` when grouping is needed, or render text directly.
`FilterPanel` no longer chooses grid columns or breakpoints: move those choices
to the consuming page. Card and TableShell retain their visual/vendor contracts.

**@smbc/ui does not own the SMBC theme.** `@smbc/devextreme-theme` owns tokens,
fonts, logo, favicon, generated DevExtreme CSS, overrides and visualization
palette. Applications still import assets/palette directly from that package.
Routing, business workflows, navigation, global typography and application
shells belong to applications. No chart abstraction is included in v0.1, and
`smbc-style` has no chart section. Application controls must use this package;
there is no direct DevExtreme import exception for charts. Extend the shared
API before introducing a new vendor control into an application.

## Basic usage

```tsx
import { Button, Field, TextInput, Select } from '@smbc/ui';

<Field label="Reference" help="Use the external reference.">
  <TextInput value={reference} onChange={setReference} />
</Field>
<Select ariaLabel="Country" options={countries} value={country} onChange={setCountry} searchable />
<Button variant="primary" onClick={save}>Save</Button>
<Button icon="refresh" ariaLabel="Refresh" onClick={refresh} />
```

Editors support controlled `value`/`onChange(value)` or uncontrolled
`defaultValue`; wrappers do not maintain a second value state. Do not switch
between these modes during a mount. Callbacks preserve DevExtreme's commit
moment (normally editor change/blur). For a deliberate vendor-specific option,
use typed `devExtremeProps`, e.g. `searchTimeout: 300` or
`valueChangeEvent: 'input'`. Common props belong on the semantic API.

`Field` hosts one editor and associates label/help/error with its input or
composite root. Set `id` on Field for a stable id; otherwise it uses React
`useId`. `required` supplies the marker and ARIA metadata; rules are explicit
through the advanced validation API below. `error` on Field renders and
associates an external error and makes the editor invalid. Without Field, give
the control `ariaLabel` (or use the deliberate input/element attribute escape
hatch). Checkbox can use its visible `label`. Field does not choose grid placement.

## Root exports and mappings

| Export | Implementation / principal props |
|---|---|
| Button | DevExtreme Button; `variant`, `icon`, `ariaLabel`, `disabled`, `submit`, `onClick()` |
| TextInput / TextArea | TextBox / TextArea; string values, placeholder, readOnly, disabled; TextArea height |
| NumberInput | NumberBox; number or null, format, min/max/step, showSpinButtons |
| Select | SelectBox; options, searchable, clearable, optionLabel/optionValue, nullable selected value |
| MultiSelect | TagBox; array value, options, searchable, selectionControls, applyMode instant/buttons |
| DatePicker | DateBox in date mode; Date/string/number/null, displayFormat, min/max |
| Checkbox | CheckBox; boolean/null value, visible label |
| RadioGroup | RadioGroup; options, optionLabel/optionValue, orientation, value |
| Tabs | Tabs; items, selectedIndex/defaultSelectedIndex, onChange(index) |
| Accordion | Accordion; items, index or selectedItems, onChange/onItemsChange, multiple/collapsible |
| DataGrid | DataGrid; corporate defaults, dataSource/keyExpr/columns, selection keys |
| Dialog / ConfirmDialog | Popup; controlled open, onClose or onCancel/onConfirm |
| Toast | Toast; open, message, tone, duration, onClose |
| LoadingIndicator | LoadIndicator; size (24 default), optional ariaLabel |
| Card | Card.Header, Card.Title, Card.Body, Card.Footer composition |
| Field | Label/control/help/error association, required marker |
| StatusBadge | neutral/info/warning/success/danger/brand tone |
| Callout | info/brand/warning/danger tone, optional title, children |
| EmptyState | icon, title, description, action; optional children |
| KpiCard | label, value, meta |
| Toolbar | DevExtreme Toolbar; items, Toolbar.Item, disabled, width, devExtremeProps |
| FilterPanel | Filter surface and padding; application-owned layout |
| TableShell | Shared border/overflow shell for a grid or native table |

Component Props types, ButtonVariant and StatusBadgeTone are exported as well.

Toolbar uses DevExtreme layout and theme styling. Place content in
`Toolbar.Item` templates. Use ordinary HTML inside templates to group related
controls. Use separate items when controls should move
individually into the overflow menu. Use our `Button` in both `render` and
`menuItemRender`; do not create vendor buttons with `widget="dxButton"` or an
equivalent `items` configuration. For disabled actions, disable both the item
and Button. With the current custom templates, clicking an action leaves the
menu open; clicking outside dismisses it. Automatic dismissal is not part of
the wrapper API. Toolbar items own overflow behaviour; an HTML wrapper only groups their content.

```tsx
<Toolbar>
  <Toolbar.Item location="before" render={() => <span>Actions</span>} />
  <Toolbar.Item
    location="after"
    locateInMenu="auto"
    render={() => <Button onClick={refresh}>Refresh</Button>}
    menuItemRender={() => <Button onClick={refresh}>Refresh</Button>}
  />
</Toolbar>
```

Button variants map to primary=default/contained, secondary=default/outlined,
tertiary=normal/text, danger=danger/contained. Omitting variant preserves the
smbc-style reference neutral contained button. Text children are strings. Icon-only
buttons require `ariaLabel` at compile time and also fail at runtime when it is
missing. A typed escape hatch can preserve an explicitly neutral outlined
reference button (`devExtremeProps={{ type: 'normal' }}`).

Select/MultiSelect/RadioGroup accept generic value and option types. Object
options can use `optionLabel="name"` and `optionValue="id"`; string arrays need
neither. Empty NumberInput yields null, matching the vendor runtime despite
its overly narrow 26.1 TypeScript declaration. Tabs provide explicit accessible names for text items, including unselected tabs.
Keep item configuration objects stable (module constants or React useMemo)
when content is unchanged; replacing objects rebuilds vendor items and can
reset keyboard focus. Tabs/Accordion ignore transient removal events when their item objects are
replaced; user selection and accordion collapse still call the semantic callbacks.

Date values are not converted
or parsed by the wrapper; timezone/serialization policies remain app-owned.

LoadingIndicator is decorative by default; pair it with a textual `role="status"`
container. Only pass ariaLabel when it must announce itself independently.

```tsx
<Card>
  <Card.Header>
    <div><Card.Title>Summary</Card.Title></div>
    <StatusBadge tone="warning">Under review</StatusBadge>
  </Card.Header>
  <Card.Body>Content</Card.Body>
  <Card.Footer><Button variant="primary">Approve</Button></Card.Footer>
</Card>
```

## Typed vendor options and migration

`devExtremeProps` is for vendor options that the wrapper does not own, plus
attributes and callbacks that it explicitly merges. Wrapper-owned options use
the top-level semantic props. The types now reject the following previously
accepted but overwritten options; JavaScript runtime precedence is unchanged.
This is a **TypeScript compatibility change**, including during local 0.1.0
development. Consumers using these object-literal options must migrate before
adopting this build; a published release must document the type change.

| Component | Move out of `devExtremeProps` | Top-level replacement |
|---|---|---|
| All eight editors | `disabled`, `readOnly` | Same names |
| TextInput, TextArea, NumberInput, DatePicker, Select, MultiSelect | `placeholder` | `placeholder` |
| TextArea | `height` | `height` |
| NumberInput | `format`, `min`, `max`, `step`, `showSpinButtons` | Same names |
| DatePicker | `displayFormat`, `min`, `max` | Same names |
| DatePicker | `type` | Date-only component; no override |
| Select, MultiSelect | `items`, `displayExpr`, `valueExpr` | `options`, `optionLabel`, `optionValue` |
| Select, MultiSelect | `searchEnabled`, `showClearButton` | `searchable`, `clearable` |
| MultiSelect | `applyValueMode`, `showSelectionControls` | `applyMode`, `selectionControls` |
| Checkbox | `text` | `label` |
| RadioGroup | `items`, `displayExpr`, `valueExpr`, `layout` | `options`, `optionLabel`, `optionValue`, `orientation` |
| Button | `width`, `stylingMode` | `width`, `variant` |
| Dialog, ConfirmDialog | `width`, `showCloseButton`, `hideOnOutsideClick` | `width`, `showCloseButton`, `closeOnOutsideClick` |
| LoadingIndicator | `width`, `height` | `size` |

For example, replace `devExtremeProps={{ applyValueMode: 'useButtons' }}` with
`applyMode="buttons"`; vendor `'instantly'` maps to `applyMode="instant"`.
Replace `hideOnOutsideClick: true` with `closeOnOutsideClick`.
For Button use secondary for outlined, tertiary for text, and primary/danger
for the respective contained actions; an omitted variant keeps neutral
contained styling. The deliberate `devExtremeProps={{ type: 'normal' }}`
override remains available for a neutral outlined secondary button.

Working extensions remain supported: `inputAttr`/`elementAttr`, `searchTimeout`,
`valueChangeEvent`, Button `type`/fallback `hint`, Dialog
`height`/`maxWidth`/`dragEnabled`, Tabs `onItemRendered`, and DataGrid defaults.
Vendor `isValid`/`validationErrors` remain usable without an external error owner.
Passing an `error` prop, even `error={undefined}` or `error=""`, selects external
validation; omitting the prop leaves vendor validation in charge. The same
presence rule applies to Field. Existing Field/control value precedence is
unchanged.

## Dialog and toast

```tsx
<ConfirmDialog
  open={open}
  title="Delete item?"
  message="This action cannot be undone."
  confirmLabel="Delete"
  confirmVariant="danger"
  onConfirm={handleDelete}
  onCancel={() => setOpen(false)}
/>
<Toast open={saved} message="Saved." tone="success" onClose={() => setSaved(false)} />
```

The caller owns open state and closes a confirmation after successful action.
ConfirmDialog uses a fade rather than a scale animation, keeping its action
buttons stationary when clicked during opening. Override animation explicitly
through `devExtremeProps` when needed.
Dialog defaults: width 600, auto height, viewport max width, close button,
no dragging, no outside-click dismissal. Escape, focus trapping and keyboard
handling remain with DevExtreme. Toast defaults to 2500 ms and calls onClose
when hiding; update open state in that callback. No business workflow is hidden
inside either component.

## DataGrid and advanced subpath

```tsx
import { DataGrid, StatusBadge } from '@smbc/ui';
import {
  DataGridColumn, DataGridFilterRow, DataGridHeaderFilter,
  DataGridSelection, DataGridPaging, DataGridPager,
} from '@smbc/ui/data-grid';

<DataGrid dataSource={rows} keyExpr="id" onSelectionChange={setSelectedKeys}>
  <DataGridSelection mode="multiple" showCheckBoxesMode="always" />
  <DataGridFilterRow visible />
  <DataGridHeaderFilter visible />
  <DataGridPaging defaultPageSize={5} />
  <DataGridPager visible showInfo showPageSizeSelector allowedPageSizes={[5, 10, 20]} />
  <DataGridColumn dataField="reference" minWidth={130} />
  <DataGridColumn dataField="amount" dataType="number" alignment="right"
    format={{ type: 'fixedPoint', precision: 2 }} />
  <DataGridColumn dataField="status"
    cellRender={({ value }) => <StatusBadge>{value}</StatusBadge>} />
</DataGrid>
```

Defaults: showBorders=false, rowAlternationEnabled=true,
hoverStateEnabled=true, columnAutoWidth=true. Simple tables can supply columns
as a prop instead. Controlled selection uses selectedRowKeys and
onSelectionChange(keys). The `data-grid` entry point intentionally exposes the
six listed DevExtreme configuration aliases, not its entire configuration
surface. The wrapper's typed devExtremeProps is the advanced escape hatch.

## Validation (advanced)

Version 0.1 preserves the working vendor validation model rather than creating
another framework. Import only the required primitives through
`@smbc/ui/validation`: Validator, RequiredRule, EmailRule, RangeRule,
ValidationGroup, ValidationSummary.

```tsx
import { Field, TextInput, Button } from '@smbc/ui';
import { ValidationGroup, ValidationSummary, Validator, RequiredRule, EmailRule } from '@smbc/ui/validation';

<form onSubmit={event => event.preventDefault()}>
  <ValidationGroup>
    <Field label="Email" required>
      <TextInput>
        <Validator>
          <RequiredRule message="Enter an email." />
          <EmailRule message="Enter a valid email." />
        </Validator>
      </TextInput>
    </Field>
    <ValidationSummary />
    <Button submit variant="primary">Validate</Button>
  </ValidationGroup>
</form>
```

ValidationRule children remain vendor-coupled advanced configuration. External
validation can instead pass Field error without a Validator. Do not use Toast
for field validation. Avoid mixing two independent validation owners on the
same control.

## Development and packed integration

The local theme dependency uses `../devextreme-theme/smbc-devextreme-theme-0.1.0.tgz`.
After regenerating the theme, refresh the development archive and its integrity
(use `--save-dev` to retain the registry peer range), then:

```sh
npm install --save-dev ../devextreme-theme/smbc-devextreme-theme-0.1.0.tgz
npm ci
# First browser setup only, when Chromium is not already installed:
npx playwright install chromium
npm run check
# Only immediately after a successful check, with no intervening source changes:
npm pack --ignore-scripts
cd ../smbc-style
npm install ../smbc-ui/smbc-ui-0.1.0.tgz
npm run lint
npm run typecheck
npm run build
```

`npm run check` builds the library once, checks package contents, then runs the
packed-consumer tests. The build already checks source types. Standalone
`typecheck`, `build`, `pack:check`, and `test` commands remain available;
`pack:check` and `test` each build first so they do not require a prepared dist.
For normal standalone packaging, use `npm pack`, which builds automatically.
Only use `npm pack --ignore-scripts` immediately after a successful check when
source files have not changed. Publication and its guard are unchanged.

Build uses TypeScript ESM plus the official Tailwind v4 CLI CSS compilation. `dist/` contains a root index,
components, data-grid and validation entry points, declaration files and
styles.css. `npm pack` builds automatically. Only dist, README and package
metadata ship. CSS is marked side-effectful for tree shaking; JS is not.

Build and package checks resolve development dependencies from the package or
an ancestor `node_modules`, including hoisted workspace installations. If
TypeScript cannot be resolved, install development dependencies with
`npm ci --include=dev` (at the workspace root for an npm workspace), then retry
`npm run check` in this package.

`npm test` packs the library, installs it and the theme into a temporary Vite
consumer, checks its runtime and compile-only type fixtures, builds the consumer
and runs headless Chromium interaction checks. The type fixture covers value
contracts, generic inference, retained vendor extensions and rejected owned
options; it is never imported into the browser. It consumes the tarball, never source aliases or symlinks. The test
requires npm access/cache and the Playwright Chromium binary. Temporary
consumers are removed after success or failure.

Repack and explicitly reinstall after source changes, including same-version
local development. Commit the application manifest and lockfile together and
share the matching archive. Publishing is not needed for local integration.

## Versioning and next candidates

PATCH: compatible fixes; MINOR: compatible components/props; MAJOR: breaking
APIs. Explicitly document breaking changes even during 0.x. Do not turn every
vendor widget into a facade. Candidates for the next release are a semantic
validation-rules API, a reusable LoadingState and a shared field description
pattern for multiple related editors, once real consumers establish the need.

## Refreshing the local three-repository setup

From `../smbc-style`, run `npm run refresh:packages`. It builds and checks the
canonical theme, installs its archive here as a devDependency, builds and checks
UI, then installs both archives in the app and runs its checks. Each repository
keeps its own lockfile and tarball boundary; no workspace or source alias is used.

### Drawers, progress and imperative refs

`Drawer` accepts controlled `open`, `onOpenChange`, a `panel` render function,
and children. Use `devExtremeProps` for positioning, overlap/shrink, shading,
geometry and reduced-motion animation settings. The application owns modal
focus containment, Escape, focus return and its routing behaviour.

`Stepper` accepts `items`, `selectedIndex`, and `readOnly`. Read-only progress
rejects user selection and disables interactive focus/hover states; applications
own business-stage calculations and accessible status text.

`Button` accepts `ref` typed as `ButtonRef`, exposing `focus()`.
`DataGrid` accepts a generic ref typed as `DataGridRef<T, K>` from
`@smbc/ui/data-grid`, retaining `instance()` for refresh, paging and filters.
The same subpath exports `DataGridLookup`, `CustomStore`, `LoadOptions` and
`LoadResultObject`. Server data policy stays with the consumer; importing these
exports does not introduce caching or alter the vendor load contract.
